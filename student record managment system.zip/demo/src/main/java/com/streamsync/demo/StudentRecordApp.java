package com.streamsync.demo;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import java.io.FileWriter;
import java.io.IOException;

/* ===================== Student Class ===================== */
class Student {
    String name;
    int rollNo;
    String course;

    Student(String name, int rollNo, String course) {
        this.name = name;
        this.rollNo = rollNo;
        this.course = course;
    }

    @Override
    public String toString() {
        return rollNo + " - " + name + " (" + course + ")";
    }
}

/* ===================== Node Class ===================== */
class Node {
    Student student;
    Node next;

    Node(Student student) {
        this.student = student;
        this.next = null;
    }
}

/* ===================== Custom Linked List ===================== */
class CustomLinkedList {
    private Node head;

    // Add Student
    public void add(Student student) {
        Node newNode = new Node(student);
        if (head == null) {
            head = newNode;
        } else {
            Node temp = head;
            while (temp.next != null)
                temp = temp.next;
            temp.next = newNode;
        }
    }

    // Delete Student
    public boolean delete(int rollNo) {
        if (head == null)
            return false;

        if (head.student.rollNo == rollNo) {
            head = head.next;
            return true;
        }

        Node temp = head;
        while (temp.next != null) {
            if (temp.next.student.rollNo == rollNo) {
                temp.next = temp.next.next;
                return true;
            }
            temp = temp.next;
        }
        return false;
    }

    // Update Student
    public boolean update(int rollNo, String newName, String newCourse) {
        Node temp = head;
        while (temp != null) {
            if (temp.student.rollNo == rollNo) {
                temp.student.name = newName;
                temp.student.course = newCourse;
                return true;
            }
            temp = temp.next;
        }
        return false;
    }

    // View All Students
    public String getAllStudents() {
        if (head == null)
            return "No students available.";

        StringBuilder sb = new StringBuilder();
        Node temp = head;
        while (temp != null) {
            sb.append(temp.student.toString()).append("\n");
            temp = temp.next;
        }
        return sb.toString();
    }

    // Save to File
    public void saveToFile(String filename) throws IOException {
        FileWriter writer = new FileWriter(filename);
        Node temp = head;
        while (temp != null) {
            writer.write(temp.student.toString() + "\n");
            temp = temp.next;
        }
        writer.close();
    }
}

/* ===================== Main JavaFX Application ===================== */
public class StudentRecordApp extends Application {

    private final CustomLinkedList studentList = new CustomLinkedList();

    @Override
    public void start(Stage stage) {
        stage.setTitle("Student Record Management System");

        /* ===================== LOGIN UI ===================== */
        Label loginLabel = new Label("Login to Student Record System");

        TextField usernameField = new TextField();
        usernameField.setPromptText("Username");

        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Password");

        Button loginBtn = new Button("Login");
        Label loginMsg = new Label();

        VBox loginLayout = new VBox(10,
                loginLabel,
                usernameField,
                passwordField,
                loginBtn,
                loginMsg
        );
        loginLayout.setPadding(new Insets(20));
        loginLayout.setBackground(new Background(
                new BackgroundFill(Color.LIGHTGRAY, CornerRadii.EMPTY, Insets.EMPTY)));

        Scene loginScene = new Scene(loginLayout, 400, 250);

        /* ===================== MAIN UI ===================== */
        TextField nameField = new TextField();
        nameField.setPromptText("Enter Name");

        TextField rollField = new TextField();
        rollField.setPromptText("Enter Roll No");

        TextField courseField = new TextField();
        courseField.setPromptText("Enter Course");

        Button addBtn = new Button("Add");
        Button deleteBtn = new Button("Delete");
        Button updateBtn = new Button("Update");
        Button viewBtn = new Button("View");
        Button saveBtn = new Button("Save");

        TextArea displayArea = new TextArea();
        displayArea.setEditable(false);

        VBox mainLayout = new VBox(10,
                new Label("Student Record Management System"),
                nameField,
                rollField,
                courseField,
                new HBox(10, addBtn, deleteBtn, updateBtn, viewBtn, saveBtn),
                displayArea
        );

        mainLayout.setPadding(new Insets(10));
        mainLayout.setBackground(new Background(
                new BackgroundFill(Color.LIGHTBLUE, CornerRadii.EMPTY, Insets.EMPTY)));

        Scene mainScene = new Scene(mainLayout, 600, 450);

        /* ===================== LOGIN ACTION ===================== */
        loginBtn.setOnAction(e -> {
            if (usernameField.getText().equals("unique")
                    && passwordField.getText().equals("108")) {
                stage.setScene(mainScene);
            } else {
                loginMsg.setText("Invalid Username or Password!");
                loginMsg.setTextFill(Color.RED);
            }
        });

        /* ===================== BUTTON ACTIONS ===================== */

        // Add Student
        addBtn.setOnAction(e -> {
            try {
                studentList.add(new Student(
                        nameField.getText(),
                        Integer.parseInt(rollField.getText()),
                        courseField.getText()
                ));
                displayArea.setText("Student Added Successfully!\n\n"
                        + studentList.getAllStudents());

                nameField.clear();
                rollField.clear();
                courseField.clear();

            } catch (Exception ex) {
                displayArea.setText("Please enter valid input!");
            }
        });

        // Delete Student
        deleteBtn.setOnAction(e -> {
            try {
                int roll = Integer.parseInt(rollField.getText());
                boolean result = studentList.delete(roll);
                if (result)
                    displayArea.setText("Student Deleted Successfully!\n\n"
                            + studentList.getAllStudents());
                else
                    displayArea.setText("Student not found!");
                rollField.clear();
            } catch (Exception ex) {
                displayArea.setText("Enter valid roll number!");
            }
        });

        // Update Student
        updateBtn.setOnAction(e -> {
            try {
                int roll = Integer.parseInt(rollField.getText());
                boolean result = studentList.update(
                        roll,
                        nameField.getText(),
                        courseField.getText()
                );
                if (result)
                    displayArea.setText("Student Updated Successfully!\n\n"
                            + studentList.getAllStudents());
                else
                    displayArea.setText("Student not found!");

                nameField.clear();
                rollField.clear();
                courseField.clear();
            } catch (Exception ex) {
                displayArea.setText("Enter valid input!");
            }
        });

        // View Students
        viewBtn.setOnAction(e ->
                displayArea.setText(studentList.getAllStudents())
        );

        // Save to File
        saveBtn.setOnAction(e -> {
            try {
                studentList.saveToFile("students.txt");
                displayArea.setText("Data saved successfully!\n\n"
                        + studentList.getAllStudents());
            } catch (IOException ex) {
                displayArea.setText("File saving error!");
            }
        });

        stage.setScene(loginScene);
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
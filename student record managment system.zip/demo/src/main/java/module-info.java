module com.streamsync.demo {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.streamsync.demo to javafx.fxml;
    exports com.streamsync.demo;
}